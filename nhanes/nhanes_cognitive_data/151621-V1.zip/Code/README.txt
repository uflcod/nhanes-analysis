Project: 	Cognitive Functioning and Demographics with NHANES
Produced by:	Center to Accelerate Population research in Alzheimer's (CAPRA)

This README document is meant to accompany the SAS and State code in this repository and aid those who wish to re-create the datasets from scratch or to apply the code to additional years of data.

The header of each programming script indicates which files are needed to run the program and which files the user should expect the program to output. Users will need to download the SAS transport files (2011-2012: DEMO_G.XPT and CFQ_G.XPT; 2013-2014: DEMO_H.XPT and CFQ_H.XPT) directly from the NHANES website. The SAS transport files should be saved to a single directory. 

Stata users will need to set their working directory to the location of the SAS transport files downloaded in the previous step. 

SAS users will need to change the path of the following libraries: 
1. cfq_g (or cfq_h, depending on year) should have the path and file name of the CFQ SAS transport file
2. demo_g (or demo_h, depending on year) should have the path and file name of the DEMO SAS transport file
3. nhanes should have the path where you want to save your outfiles. 

Once the pathnames have been updated to reflect the location of the SAS transport files, users should be able to run the programming scripts in their own environment. 